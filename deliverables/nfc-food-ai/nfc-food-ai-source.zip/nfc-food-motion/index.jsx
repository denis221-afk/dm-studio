import React from 'react';
import {AbsoluteFill,Composition,registerRoot,useCurrentFrame,interpolate,Img,staticFile,Audio,Easing} from 'remotion';
const lime='#d9ff63',muted='#adb3a4',ease=Easing.bezier(.22,1,.36,1);
const mix=(f,a,b,x,y)=>interpolate(f,[a,b],[x,y],{extrapolateLeft:'clamp',extrapolateRight:'clamp',easing:ease});
const fade=(f,a,b,c,d)=>mix(f,a,b,0,1)*(1-mix(f,c,d,0,1));
const css=`@font-face{font-family:Manrope;src:url('${staticFile('Manrope.woff2')}')}@font-face{font-family:Manrope;src:url('${staticFile('ManropeLatin.woff2')}');unicode-range:U+0000-024F}*{box-sizing:border-box}`;
const Kicker=({children})=><div style={{color:lime,fontSize:27,letterSpacing:5}}>{children}</div>;
function Heading({f,a,b,c,d,kicker,children}){return <div style={{position:'absolute',left:84,top:225,width:810,opacity:fade(f,a,b,c,d),transform:`translateY(${mix(f,a,b,24,0)}px)`}}><Kicker>{kicker}</Kicker><div style={{fontSize:76,lineHeight:1.12,letterSpacing:-3,marginTop:25}}>{children}</div></div>}
const pill={padding:'15px 22px',borderRadius:30,background:lime,color:'#11150e',fontSize:24,display:'inline-block'};
function Movie({cover=false}){
const raw=useCurrentFrame(),f=cover?0:raw;
const p=mix(f,45,83,0,1),r=mix(f,249,282,0,1),tg=mix(f,415,441,0,1),loop=mix(f,660,689,0,1);
const w=cover?840:(840-330*p+310*r-310*tg)*(1-loop)+840*loop;
const h=cover?840:(840+116*p-116*r+116*tg)*(1-loop)+840*loop;
const x=cover?72:(72+138*p-130*r+130*tg)*(1-loop)+72*loop;
const y=cover?650:(650-130*p+65*r-65*tg)*(1-loop)+650*loop;
const photoOpacity=cover?1:Math.max(1-mix(f,72,91,0,1),loop);
const screenOpacity=mix(f,72,91,0,1)*(1-mix(f,249,270,0,1))*(1-loop);
return <AbsoluteFill style={{fontFamily:'Manrope,sans-serif',fontWeight:700,background:'#0e100e',color:'#f8faef',overflow:'hidden'}}><style>{css}</style>
<AbsoluteFill style={{background:'radial-gradient(ellipse at 15% 50%,#27301c,transparent 54%),radial-gradient(ellipse at 90% 6%,#202618,transparent 45%)'}}/>
<div style={{position:'absolute',top:116,left:84,color:muted,fontSize:27,letterSpacing:3}}>DM STUDIO <span style={{color:lime}}> / </span> FOOD × AI</div>
{cover?<div style={{position:'absolute',top:280,left:84}}><Kicker>NFC FOOD AI</Kicker><div style={{fontSize:100,lineHeight:1.12,letterSpacing:-5,marginTop:36}}>Фото →<br/><span style={{color:lime}}>калорії?</span></div></div>:<>
<Heading f={f} a={-10} b={0} c={49} d={65} kicker="NFC FOOD AI">Скільки калорій<br/>у цій тарілці?</Heading>
<Heading f={f} a={59} b={77} c={137} d={151} kicker="01 / ВІДКРИТТЯ">NFC →<br/><span style={{color:lime}}>вебсервіс</span></Heading>
<Heading f={f} a={147} b={166} c={251} d={267} kicker="02 / ФОТО">Додав фото.<br/>Аналіз почався.</Heading>
<Heading f={f} a={263} b={283} c={409} d={425} kicker="03 / ПРИБЛИЗНО">Що у страві?<br/><span style={{color:lime}}>AI оцінює.</span></Heading>
<Heading f={f} a={415} b={434} c={554} d={571} kicker="04 / ІНТЕГРАЦІЇ">Результат →<br/><span style={{color:lime}}>Telegram</span></Heading>
</>}
<div style={{position:'absolute',left:x,top:y,width:w,height:h,borderRadius:58-14*p+14*r,overflow:'hidden',background:'#191d16',border:`${2+8*p-8*r}px solid #343b2c`,boxShadow:'0 50px 120px #0008'}}>
<Img src={staticFile('food.png')} style={{width:'100%',height:'100%',objectFit:'cover',position:'absolute',opacity:photoOpacity,transform:`scale(${1.015+mix(f,0,45,.035,0)+loop*.035})`}}/>
<Img src={staticFile('product-live.png')} style={{width:'100%',height:'100%',objectFit:'fill',position:'absolute',opacity:screenOpacity}}/>
{!cover&&<>
<Img src={staticFile('loading-live.png')} style={{position:'absolute',inset:0,width:'100%',height:'100%',opacity:fade(f,203,219,251,271)}}/>
<Img src={staticFile('success-live.png')} style={{position:'absolute',inset:0,width:'100%',height:'100%',opacity:fade(f,425,444,551,574)}}/>
<div style={{position:'absolute',inset:0,padding:40,opacity:fade(f,255,277,418,436),background:'#1a2016'}}>
<div style={{display:'flex',gap:25,alignItems:'center'}}><Img src={staticFile('food.png')} style={{width:150,height:150,objectFit:'cover',borderRadius:28}}/><div><div style={pill}>Реальні дані API</div><div style={{fontSize:32,marginTop:14}}>Приблизна AI-оцінка</div></div></div>
<div style={{height:2,background:'#414a35',margin:'30px 0'}}/>
<div style={{opacity:1-mix(f,289,303,0,1),position:'absolute',top:260,fontSize:42,color:lime}}>Аналіз фото<span style={{opacity:.5+Math.sin(f/9)*.5}}>…</span></div>
<div style={{opacity:mix(f,294,310,0,1)}}><div style={{fontSize:98,color:lime,letterSpacing:-5}}>≈ 520 <span style={{fontSize:37,letterSpacing:0}}>ккал</span></div><div style={{fontSize:27,color:muted}}>Оцінка для показаного фото</div></div>
{[['Білки','48 г',318],['Жири','14 г',337],['Вуглеводи','45 г',356]].map(([name,val,start])=><div key={name} style={{display:'flex',justifyContent:'space-between',fontSize:40,marginTop:24,opacity:mix(f,start,start+13,0,1),transform:`translateY(${mix(f,start,start+13,14,0)}px)`}}><span style={{color:muted}}>{name}</span><span>{val}</span></div>)}
<div style={{fontSize:25,lineHeight:1.45,color:muted,marginTop:28}}>Візуалізація відповіді API.<br/>Не точне вимірювання.</div>
</div>

</>}
</div>
{!cover&&<>
<Img src={staticFile('food.png')} style={{position:'absolute',left:300,top:820,width:340,height:340,objectFit:'cover',borderRadius:35,border:'3px solid #d9ff63',opacity:fade(f,155,170,194,211),transform:`translateY(${mix(f,175,211,0,240)}px) scale(${mix(f,175,211,1,.35)})`}}/>
<div style={{position:'absolute',left:695,top:1010,width:205,height:205,borderRadius:45,border:'2px solid #57623c',background:'#252d1b',opacity:fade(f,61,80,123,144),transform:`translateX(${mix(f,61,80,70,0)}px)`}}><div style={{fontSize:55,color:lime,textAlign:'center',marginTop:30}}>)))</div><div style={{fontSize:29,textAlign:'center',marginTop:12}}>NFC</div>{[0,1].map(i=><div key={i} style={{position:'absolute',inset:-15-i*15,border:`2px solid ${lime}`,borderRadius:60,opacity:fade(f,83+i*5,90+i*5,102+i*5,112+i*5),transform:`scale(${mix(f,83,120,1,1.35)})`}}/>)}</div>
{[[66,83,136,151,<>Ілюстрація NFC-сценарію.<br/>У телефоні — реальний екран.</>],[154,172,246,264,<>Фото → завантаження → аналіз<br/><span style={{color:lime}}>Реальний екран сервісу.</span></>],[273,290,406,425,<>КБЖВ за фото — приблизно.<br/>Не медична рекомендація.</>],[432,448,550,568,<>Аналіз готовий.<br/><span style={{color:lime}}>Кнопка відкриває Telegram-бота.</span></>]].map(([a,b,c,d,text])=><div key={a} style={{position:'absolute',left:84,top:1500,width:800,fontSize:31,color:muted,lineHeight:1.5,opacity:fade(f,a,b,c,d)}}>{text}</div>)}
<AbsoluteFill style={{background:'#0e100e',opacity:fade(f,555,578,652,677)}}><div style={{position:'absolute',left:84,top:290,width:800}}><Kicker>ІДЕЯ → РОБОЧЕ РІШЕННЯ</Kicker><div style={{fontSize:94,letterSpacing:-5,lineHeight:1.12,marginTop:65}}>NFC<br/><span style={{color:lime}}>Food AI</span></div><div style={{fontSize:35,color:muted,marginTop:32}}>Розроблено DM Studio</div><div style={{width:680,height:2,background:'#3b4430',marginTop:80}}/><div style={{fontSize:49,lineHeight:1.3,marginTop:55}}>Потрібне рішення<br/>для бізнесу?</div><div style={{fontSize:76,letterSpacing:-3,color:lime,marginTop:45}}>Напиши «AI»</div></div></AbsoluteFill>
<Heading f={f} a={663} b={689} c={710} d={720} kicker="NFC FOOD AI">Скільки калорій<br/>у цій тарілці?</Heading>
</>}
<div style={{position:'absolute',left:84,top:1620,fontSize:24,color:muted,opacity:cover?1:Math.max(1-mix(f,40,60,0,1),loop)}}>Ілюстрація страви • фото створене AI</div>
{cover&&<div style={{position:'absolute',left:84,top:1550,fontSize:34,color:muted}}>Приблизна оцінка за фотографією</div>}
{!cover&&<Audio src={staticFile('accents.wav')}/>}
</AbsoluteFill>}
function Root(){return <><Composition id="NFCFoodAI" component={Movie} durationInFrames={690} fps={30} width={1080} height={1920}/><Composition id="Cover" component={Movie} defaultProps={{cover:true}} durationInFrames={1} fps={30} width={1080} height={1920}/></>};registerRoot(Root);

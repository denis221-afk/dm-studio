import {Config} from '@remotion/cli/config';
Config.setBrowserExecutable('/usr/bin/chromium');
Config.setConcurrency(2);
Config.setVideoImageFormat('jpeg');
Config.setJpegQuality(95);

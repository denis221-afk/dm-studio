import math,wave,struct
rate=48000
samples=[0.]*(23*rate)
for start,notes,amp in [(2.82,[880,1320],.11),(10.0,[523.25,659.25,783.99],.085),(14.65,[784,1046.5],.09)]:
 for k,hz in enumerate(notes):
  for j in range(int(.18*rate)):
   t=j/rate; at=int((start+k*.065)*rate)+j
   envelope=(1-math.exp(-t*160))*math.exp(-t*25)
   samples[at]+=amp*envelope*math.sin(2*math.pi*hz*t)
with wave.open('public/accents.wav','wb') as w:
 w.setparams((2,2,rate,0,'NONE','not compressed'))
 w.writeframes(b''.join(struct.pack('<hh',int(max(-1,min(1,x))*32767),int(max(-1,min(1,x))*32767)) for x in samples))
